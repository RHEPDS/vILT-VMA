# AlfsMigrationToolkit

**AlfsMigrationToolkit** analyzes RVTools exports (XLSX/CSV) or live vCenter data and produces migration recommendations and a phased migration plan for moving workloads from **VMware vSphere** to **OpenShift Virtualization**, including guidance aligned with **Migration Toolkit for Virtualization (MTV)**.

The app is a [Streamlit](https://streamlit.io/) web UI with **English, German, and French** UI strings, a splash screen (license, disclaimer, feedback), and **Back / Next** navigation at the bottom of each page.

## Features

- **Data import**: Upload an RVTools file (XLSX/CSV) or connect to **vCenter** via the live API (pyvmomi).
- **Analysis**: VM overview, cluster selection, compatibility-style recommendations per VM (cold/warm migration hints, effort).
- **OS analysis**: Guest OS distribution with Microsoft / Red Hat lifecycle-style notes (where data allows).
- **Configuration**: Target worker size, CPU/memory overcommit, optional ODF storage design, HA settings, subscription list-price assumptions.
- **Cluster design**: Required worker nodes, utilization, density and power savings estimates, optional ODF capacity.
- **HA & network**: HA recommendations, recommended network settings table, optional **Graphviz** topology diagram (requires system `graphviz` + Python `graphviz`).
- **Migration plan & risk**: Phased plan, global and per-phase risk notes, downloadable Markdown (including risk section) in the **selected UI language**.
- **Deploy prototype**: Generate `install-config.yaml` and helper scripts for **openshift-install** on AWS, Azure, IBM Cloud, or bare metal (with optional cost hints for cloud bare-metal SKUs).

## Requirements

- **Python** 3.9 or newer (3.11+ recommended).
- **RVTools** export: *File → Export all to Excel* (or CSV), or vCenter credentials for live import.
- For **Graphviz diagrams** on the HA page: install the system `graphviz` package and the `graphviz` Python package (see `requirements.txt`).

## Installation

```bash
cd amt
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run locally

```bash
streamlit run app.py
```

Or use the helper script:

```bash
./run.sh
```

Open **http://localhost:8501** in your browser.

## Docker

Build:

```bash
docker build -t alfs-migration-toolkit:latest .
```

Run:

```bash
docker run --rm -p 8501:8501 alfs-migration-toolkit:latest
```

The image includes the system `graphviz` binaries for topology rendering. Application assets (e.g. splash image) are copied from the `assets/` directory.

## Kubernetes

If you use the provided manifests:

```bash
# push image to your registry (optional)
docker tag alfs-migration-toolkit:latest <registry>/alfs-migration-toolkit:latest
docker push <registry>/alfs-migration-toolkit:latest

kubectl apply -f k8s-deployment.yaml
```

Adjust the **Ingress** host and TLS settings in `k8s-deployment.yaml` for your domain. For quick local access without an ingress controller:

```bash
kubectl port-forward svc/alfs-migration-toolkit 8501:80
```

## Typical workflow

1. Choose **file upload** or **vCenter** (if available) and import VM data.
2. On **Analysis**, select clusters and review metrics, recommendations, migration plan preview, and exports.
3. Use **Configuration** for worker sizing, overcommit, ODF, HA, and optional subscription assumptions.
4. Review **Cluster design**, **HA & network**, and **Migration plan & risk**: plans and risk text follow the **language** selected in the UI.
5. **Deploy** (optional): fill in platform fields and download generated install artifacts.

Use the sidebar or the **Back / Next** buttons at the bottom of each page to move between steps.

## RVTools data

- **vInfo** (primary): VM name, power state, CPUs, memory, provisioned/in-use storage, cluster, host, guest OS, UUID, etc.
- Additional sheets (e.g. vDisk, vNIC) can improve detail for recommendations.

## Notes

- Storage figures in RVTools are often in **MiB**; the app treats them consistently for planning.
- MTV, cold vs warm migration, and VDDK are reflected in the narrative and export; validate against your target OpenShift and Red Hat documentation before production cutovers.
- **Credentials** (vCenter, cloud, pull secret) are used only in the browser session to generate files; do not commit secrets.

## License

This project is released under the **GNU General Public License v2.0** (GPL-2.0-only). See the splash screen and project files for the full notice.

## Pushing to GitHub

Example:

1. Create a new repository on GitHub **without** a generated README, `.gitignore`, or license (if you want a clean history).
2. Add the remote and push:

```bash
git remote add origin https://github.com/YOUR-USERNAME/your-repo-name.git
git branch -M main
git push -u origin main
```

SSH:

```bash
git remote add origin git@github.com:YOUR-USERNAME/your-repo-name.git
git push -u origin main
```
